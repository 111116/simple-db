#pragma once

#include "database.h"

void drop(std::string dbName);
void create(std::string dbName);
void use(std::string dbName);
void show();
